<?php $__env->startSection('innerpage'); ?>

<section class="h-100 gradient-form" style="background-color: #eee;">
    <br>
  <div class="container py-5 h-100"style="background-color: white;">

<table class="table" >
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Contact</th>
      <th scope="col">Email</th>
      <th scope="col">Current Balance</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $lims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($key+1); ?></th>
      <td><?php echo e($item->name); ?></td>
      <td><?php echo e($item->contact); ?></td>
      <td><?php echo e($item->email); ?></td>
      <td><?php echo e($item->current_bal); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  </tbody>
</table>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\LARAVELPROJECTS\cap2cash\resources\views/home.blade.php ENDPATH**/ ?>