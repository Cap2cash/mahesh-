<html>
    <head>
        <link href="<?php echo e(asset('public/assets/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('public/assets/css/styles.css')); ?>" rel="stylesheet">
         <script src="<?php echo e(asset('public/assets/bootstrap/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('public/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
    </head>
    <body>
<br>
        <div class="col-sm-10">
            <div class="d-flex align-items-center justify-content-center pb-4">
                <a type="button" class="btn btn-outline-danger" href="<?php echo e(Route('home')); ?>">Users</a> &nbsp;&nbsp;
                <a type="button" class="btn btn-outline-danger" href="<?php echo e(Route('withdraw')); ?>">Withdraw</a>&nbsp;&nbsp;
                <a type="button" class="btn btn-outline-danger" href="<?php echo e(Route('logout')); ?>">Logout</a>
            </div>
        </div>
        <?php echo $__env->yieldContent('innerpage'); ?>
    </body>


 </html>
<?php /**PATH D:\xampp\htdocs\LARAVELPROJECTS\cap2cash\resources\views/layout.blade.php ENDPATH**/ ?>